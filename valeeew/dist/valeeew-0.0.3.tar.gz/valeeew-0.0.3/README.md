# Valeeew

> ## By Valentin MONTEIRO
___
### Table of contents
- Introduction
- Cleaning
- Outliers
  - IQR
  - Z-score
- Credits
___
## Introduction

Toolbox made for data manipulation, the goal is to reduce time-consuming tasks. If you want to participate, or simply give ideas, I would be happy to discuss, or even work with you on this project ! 

## Cleaning
### watch
function to make a quick overview of the DATAframe
## Outliers
### IQR
function to highlight outliers using the IQR method
### Z-score
function to highlight outliers using the Z-score method
___
## Credits
> People involved in the project